<?php
/**
 * shadowsocks-panel
 * Add: 2016/5/13 10:14
 * Author: Sendya <18x@loacg.com>
 */

namespace Helper;

/**
 * Class Downloader
 * @package Helper
 */
class Downloader
{
    public static function save($name, $list)
    {

    }

    public static function download($path, $hash, $try = 1)
    {

    }

}